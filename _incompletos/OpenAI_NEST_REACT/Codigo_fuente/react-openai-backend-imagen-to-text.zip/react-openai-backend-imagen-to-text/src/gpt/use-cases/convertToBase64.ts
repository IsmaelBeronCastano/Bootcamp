export function convertToBase64(file: Express.Multer.File) {
  // return `data:image/jpeg;base64,${file.buffer.toString('base64')}`;
}
