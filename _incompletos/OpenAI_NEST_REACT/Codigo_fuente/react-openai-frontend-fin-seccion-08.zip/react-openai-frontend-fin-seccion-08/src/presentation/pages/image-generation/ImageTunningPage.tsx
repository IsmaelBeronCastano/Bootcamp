export const ImageTunningPage = () => {
  return (
    <div>ImageTunningPage</div>
  )
}