
export interface TranslateResponse {
  message: string;
}
