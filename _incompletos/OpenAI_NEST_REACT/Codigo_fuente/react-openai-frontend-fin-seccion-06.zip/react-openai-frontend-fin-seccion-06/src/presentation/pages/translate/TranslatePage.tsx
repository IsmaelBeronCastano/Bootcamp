export const TranslatePage = () => {
  return (
    <div>TranslatePage</div>
  )
}