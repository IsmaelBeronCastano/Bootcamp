export const AssistantPage = () => {
  return (
    <div>AssistantPage</div>
  )
}