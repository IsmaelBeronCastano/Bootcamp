
# Instalación en Dev


1. Clonar el repositorio
2. Instalar dependencias ```npm install -f```
3. Crear archivo .env basado en el .env.template
4. Ejecutar ```npm run start:dev```
   
   
