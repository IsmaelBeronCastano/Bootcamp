export const ImageGenerationPage = () => {
  return (
    <div>ImageGenerationPage</div>
  )
}