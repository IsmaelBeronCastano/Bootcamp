export const ProsConsStreamPage = () => {
  return (
    <div>ProsConsStreamPage</div>
  )
}