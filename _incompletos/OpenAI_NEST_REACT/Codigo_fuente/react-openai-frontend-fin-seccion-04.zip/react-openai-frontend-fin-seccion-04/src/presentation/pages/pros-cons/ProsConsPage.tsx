export const ProsConsPage = () => {
  return (
    <div>ProsConsPage</div>
  )
}