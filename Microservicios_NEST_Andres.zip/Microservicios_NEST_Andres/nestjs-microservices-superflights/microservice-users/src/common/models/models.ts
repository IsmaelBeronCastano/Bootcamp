export const USER = { name: 'users' };
