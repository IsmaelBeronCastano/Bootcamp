export class PassengerDTO {
  readonly name: string;
  readonly email: string;
}
