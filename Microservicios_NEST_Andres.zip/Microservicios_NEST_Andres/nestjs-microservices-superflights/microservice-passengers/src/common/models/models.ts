export const PASSENGER = { name: 'passengers' };
