export interface IPassenger {
  name: string;
  email: string;
}
