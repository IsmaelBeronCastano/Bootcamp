export interface IUser {
  name: string;
  username: string;
  email: string;
  password: string;
}
